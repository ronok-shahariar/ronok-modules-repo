#include <iostream>

void run_tool() {
    std::cout << "C++ Tools v1.1.0 loaded!" << std::endl;
}
