def run():
    return "Sample module v1.2.0 is running successfully!"
