def run():
    return "Sample module v1.0.0 is running successfully!"
