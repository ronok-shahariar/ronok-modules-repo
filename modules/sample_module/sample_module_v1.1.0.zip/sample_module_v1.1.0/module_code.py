def run():
    return "Sample module v1.1.0 is running successfully!"