def apply_patch():
    return "GUI Patch v2.0.0 applied successfully!"
