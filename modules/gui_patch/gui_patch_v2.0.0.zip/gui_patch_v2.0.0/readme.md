# GUI Patch v2.0.0

- Complete redesign of main UI.
- Improved loading speed by 40%.
- Added dark theme enhancements.
